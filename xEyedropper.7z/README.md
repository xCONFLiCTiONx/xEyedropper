# xEyedropper
Grab the color from the pixel under the mouse cursor

![Screenshot1](https://github.com/xCONFLiCTiONx/xEyedropper/blob/master/Screenshot1.jpg)  

![Screenshot2](https://github.com/xCONFLiCTiONx/xEyedropper/blob/master/Screenshot2.jpg)  
